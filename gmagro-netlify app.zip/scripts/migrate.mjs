import {readFile} from 'node:fs/promises';
import pg from 'pg';
if(!process.env.DATABASE_URL)throw Error('Set DATABASE_URL securely before running migrations');
const client=new pg.Client({connectionString:process.env.DATABASE_URL});
try{await client.connect();await client.query(await readFile(new URL('../supabase/migrations/001_erp.sql',import.meta.url),'utf8'));console.log('ERP tables and private evidence bucket are ready.');}finally{await client.end();}
