BEGIN;
CREATE TABLE IF NOT EXISTS members (email text PRIMARY KEY,user_id text,name text NOT NULL,role text NOT NULL,region text NOT NULL);
CREATE TABLE IF NOT EXISTS records (id text PRIMARY KEY,kind text NOT NULL,owner text NOT NULL,region text NOT NULL,stage text NOT NULL,data text NOT NULL CHECK (jsonb_typeof(data::jsonb)='object'),version integer NOT NULL DEFAULT 1,created text NOT NULL,updated text NOT NULL);
CREATE TABLE IF NOT EXISTS audit (id text PRIMARY KEY,record text NOT NULL,actor text NOT NULL,role text NOT NULL,action text NOT NULL,at text NOT NULL,detail text NOT NULL);
CREATE TABLE IF NOT EXISTS tracking (email text PRIMARY KEY,consent integer NOT NULL DEFAULT 0,active integer NOT NULL DEFAULT 0,device text NOT NULL,session text NOT NULL,changed text NOT NULL,policy text NOT NULL);
CREATE TABLE IF NOT EXISTS notifications (id text PRIMARY KEY,event text NOT NULL,record text NOT NULL,recipient text NOT NULL,subject text NOT NULL,body text NOT NULL,status text NOT NULL,attempts integer NOT NULL DEFAULT 0,provider text,error text,created text NOT NULL,updated text NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS notification_event_recipient ON notifications(event,recipient);
CREATE TABLE IF NOT EXISTS uploads (key text PRIMARY KEY,owner text NOT NULL,name text NOT NULL,type text NOT NULL,size integer NOT NULL CHECK(size BETWEEN 1 AND 26214400),created text NOT NULL);
CREATE INDEX IF NOT EXISTS records_kind_created ON records(kind,created);
CREATE INDEX IF NOT EXISTS audit_record_at ON audit(record,at);
CREATE INDEX IF NOT EXISTS uploads_created ON uploads(created);
-- All ERP data is reached through authenticated, role-scoped server routes.
-- Browser keys get no direct table access; PostgreSQL server connection stays secret.
ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE records ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit ENABLE ROW LEVEL SECURITY;
ALTER TABLE tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE uploads ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON members,records,audit,tracking,notifications,uploads FROM anon,authenticated;
INSERT INTO storage.buckets(id,name,public,file_size_limit,allowed_mime_types) VALUES('erp-evidence','erp-evidence',false,26214400,ARRAY['image/jpeg','image/png','image/webp','video/mp4','video/webm','video/quicktime']) ON CONFLICT(id) DO UPDATE SET public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
-- No public policies are added to storage.objects. Server-authorized signed URLs only.
COMMIT;
